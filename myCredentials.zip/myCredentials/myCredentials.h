#ifndef WIFI_CREDENTIALS_H
#define WIFI_CREDENTIALS_H

#define WIFI_SSID "your ssid"
#define WIFI_PSK "your pre shared key"

#define OTApassword "make up a cool password"

#define MQTT_SERVER "you mqtt brokers ip address"  // like so "192.168.123.234"
#define MQTT_USERNAME "pretty self explanatory"
#define MQTT_PASSWORD "and this one too"

#endif