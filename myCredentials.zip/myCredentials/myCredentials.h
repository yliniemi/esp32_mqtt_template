#ifndef MY_CREDENTIALS_H
#define MY_CREDENTIALS_H

// you can define multiple wifi credentials here. just copy paste the line with your wifi credentials and fill it with the new ones
#ifdef SETUPWIFI_CPP
char* wifiArray[][2] = {
	{"MyFirstWLAN", "randompresharedkey"},
	{"MySecondWLAN", "alsorandompresharedkey"},
	{0, 0}};						// this needs to be like this to that wifisetup knows when we have tried all the access poins and gices up
#define TRY_DISCONNECTING 5			// after this many tries to reconnect try to disconnect before reconnecting
#define TIME_TO_REBOOT 30			// after this many tries give up and reboot your esp32
#endif

#define OTA_PASSWORD "make up a cool password"
#define OTA_ROUNDS 32             	// this is how many seconds we waste waiting for the OTA during boot. sometimes people make mistakes in their code - not me - and the program freezes. this way you can still update your code over the air even if you have some dodgy code in your loop

#define MQTT_SERVER "you mqtt brokers ip address"  // like so "192.168.123.234"
#define MQTT_USERNAME "pretty self explanatory"
#define MQTT_PASSWORD "and this one too"

#endif